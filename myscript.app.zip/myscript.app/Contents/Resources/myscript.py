# Import the required libraries
from tkinter import *
import webview
from os.path import exists
###########
import tkinter as tk
from tkinter import simpledialog
a = 1
ROOT = tk.Tk()
USER_INP =''
# the input dialog

USER_INP = simpledialog.askstring(title="URLBAR",
                                prompt="Enter Website URL:")

# check it out

##########

#Set Repeat Execution Variables
a = 1

# Create an instance of tkinter frame or window

bookmarks = 'bookmarks'
# Set the size of the window

# Create a GUI window to view the HTML content
#Ask user for website

webview.create_window(USER_INP, USER_INP)
webview.start()

while a == 1:
    USER_INP = simpledialog.askstring(title="URLBAR",
                                prompt="Enter Website URL:")
    webview.create_window(USER_INP,  USER_INP)
    webview.start()


    
